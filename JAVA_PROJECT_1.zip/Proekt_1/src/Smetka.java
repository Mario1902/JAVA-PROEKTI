
public class Smetka {

	public static void main(String[] args) {
		int jab=32;
		int komp=20;
		int pras=50;
		double rezultat;
		rezultat=(jab*2)+(komp*5)+(pras*2.5);
		System.out.println("Vkupno vo denari:");
		System.out.println(rezultat);
	}
}
