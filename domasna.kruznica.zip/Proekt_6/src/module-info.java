/**
 * 
 */
/**
 * 
 */
module Proekt_6 {
}