
public class Menuvacnica {
	public static void main(String[] args) {
		double evra=500;
		double denari_vrednost=61.7;
		double rezultat=evra*denari_vrednost;
		
		System.out.println("Zadadena vrednost za evra : ");
		System.out.println(evra);
		System.out.print("Pretvoreni vo denari se : ");
		System.out.print(rezultat);
	}
}
